﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Esm/ProgramBase.hpp"
#include "Arp/System/Commons/Logging.h"
#include "COMP_Grinder.hpp"

namespace LIB_Grinder
{

using namespace Arp;
using namespace Arp::System::Commons::Diagnostics::Logging;
using namespace Arp::Plc::Commons::Esm;

//#program
//#component(LIB_Grinder::COMP_Grinder)
class PG_Grinder : public ProgramBase, private Loggable<PG_Grinder>
{
public: // typedefs

public: // construction/destruction
    PG_Grinder(LIB_Grinder::COMP_Grinder& cOMP_GrinderArg, const String& name);
    PG_Grinder(const PG_Grinder& arg) = delete;
    virtual ~PG_Grinder() = default;

public: // operators
    PG_Grinder&  operator=(const PG_Grinder& arg) = delete;

public: // properties

public: // operations
    void    Execute() override;

public:

    // -----------------------------------------------
    // Input ports
    //------------------------------------------------

    //#port
    //#attributes(Input)
    uint16 INPORT_uiIntensity = 0;

    //#port
    //#attributes(Input)
    boolean INPORT_xStartButton = false;

    //#port
    //#attributes(Input)
    boolean INPORT_xStopButton = false;

    //#port
    //#attributes(Input)
    boolean INPORT_xReset = false;

    //#port
    //#attributes(Input)
    boolean INPORT_xGrinderBlocked = false;

    //#port
    //#attributes(Input)
    boolean INPORT_xNoCoffeeBeans = false;

    //#port
    //#attributes(Input)
    boolean INPORT_xPot = false;


    // -----------------------------------------------
    // Output ports
    //------------------------------------------------

    //#port
    //#attributes(Output)
    boolean OUTPORT_xGrinder = false;

    //#port
    //#attributes(Output)
    boolean OUTPORT_xGrinderFinish = false;

    //#port
    //#attributes(Output)
    float64 OUTPORT_fNeededGrindingDuration = 0.0;

    //#port
    //#attributes(Output)
    float64 OUTPORT_fActualGrindingDuration = 0.0;

    // -----------------------------------------------
    // Interanl variables
    //------------------------------------------------

    // Time structures
    struct timeval stNow, stStart, stInteruptStart, stInteruptStop;

    // Time as float64
    float64 fNow = 0.0;
    float64 fLastStart = 0.0;
    float64 fInterrupt = 0.0;
    float64 fInterruptStart = 0.0;
    float64 fInterruptStop = 0.0;

    // Flags for edge detection
    boolean xFlagStartButton = false;
    boolean xFlagGrinder = false;
    boolean xFlagInterrupt = false;
    boolean xInterrupted = false;

private: // fields
    LIB_Grinder::COMP_Grinder& cOMP_Grinder;

};

///////////////////////////////////////////////////////////////////////////////
// inline methods of class ProgramBase
inline PG_Grinder::PG_Grinder(LIB_Grinder::COMP_Grinder& cOMP_GrinderArg, const String& name)
: ProgramBase(name)
, cOMP_Grinder(cOMP_GrinderArg)
{
}

} // end of namespace LIB_Grinder
