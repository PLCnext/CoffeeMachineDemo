﻿#include "COMP_Grinder.hpp"
#include "Arp/Plc/Commons/Esm/ProgramComponentBase.hpp"
#include "Proj_GrinderLibrary.hpp"

namespace LIB_Grinder
{

COMP_Grinder::COMP_Grinder(IApplication& application, const String& name)
: ComponentBase(application, ::LIB_Grinder::Proj_GrinderLibrary::GetInstance(), name, ComponentCategory::Custom)
, programProvider(*this)
, ProgramComponentBase(::LIB_Grinder::Proj_GrinderLibrary::GetInstance().GetNamespace(), programProvider)
{
}

void COMP_Grinder::Initialize()
{
    // never remove next line
    ProgramComponentBase::Initialize();

    // subscribe events from the event system (Nm) here
}

void COMP_Grinder::LoadConfig()
{

}

void COMP_Grinder::SetupConfig()
{
    // never remove next line
    ProgramComponentBase::SetupConfig();

    // setup project config here
}

void COMP_Grinder::ResetConfig()
{
    // never remove next line
    ProgramComponentBase::ResetConfig();

    // implement this inverse to SetupConfig() and LoadConfig()
}

} // end of namespace LIB_Grinder
