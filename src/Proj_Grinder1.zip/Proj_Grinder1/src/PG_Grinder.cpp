﻿#include "PG_Grinder.hpp"
#include "Arp/System/Commons/Logging.h"
#include "Arp/System/Core/ByteConverter.hpp"

#include <sys/time.h>

namespace LIB_Grinder
{
 
void PG_Grinder::Execute()
{
	// *********************************************************************************************************
	// When the start button is pressed, start the grinding process and run it for the required calculated time
	// *********************************************************************************************************

	// Determine actual time
	if (!INPORT_xGrinderBlocked & !INPORT_xNoCoffeeBeans)
	{
		gettimeofday(&stNow, (struct timezone *)0);
		fNow = float64(stNow.tv_sec + stNow.tv_usec * 1e-6);
	}


	// *********************************************************************************************************
	// If a rising edge occurs when the start button is pressed and the grinding process isn't already started,
	// the set grinding time is calculated, the last start time is determined and the grinding state is on
	// *********************************************************************************************************

	if (INPORT_xStartButton & !xFlagStartButton & !OUTPORT_xGrinder & !xInterrupted & !INPORT_xGrinderBlocked & !INPORT_xNoCoffeeBeans) // Detect rising edge of the start button
	{
		// Calculate grinding time
		if (!INPORT_xPot)
		{
			OUTPORT_fNeededGrindingDuration = (float64(INPORT_uiIntensity)/10000.0) + 3.0;
		}
		else if (INPORT_xPot)
		{
			OUTPORT_fNeededGrindingDuration = ( (220.0/125.0) * (float64(INPORT_uiIntensity)/10000.0) ) + 3.0;
		}

		// Determine start time of grinding
		gettimeofday(&stStart, (struct timezone *)0);
		fLastStart = float64(stStart.tv_sec + stStart.tv_usec * 1e-6);

		// Grinding is started
		OUTPORT_xGrinder = true;
	}

	// *********************************************************************************************************
	// If the interrupt button is pressed during operation of the grinder, this time is to be detected and the
	// grinding status is to be set to "false".
	// *********************************************************************************************************

	else if (INPORT_xStopButton & !xFlagInterrupt & OUTPORT_xGrinder) // Detect stop button activation
	{
		xInterrupted = true;
		OUTPORT_xGrinder = false;

		gettimeofday(&stInteruptStart, (struct timezone *)0);
		fInterruptStart = float64(stInteruptStart.tv_sec + stInteruptStart.tv_usec * 1e-6);
	}

	// *********************************************************************************************************
	// If the start button is pressed after an interruption, continue with the grinding process
	// *********************************************************************************************************

	else if (xInterrupted & INPORT_xStartButton & !xFlagStartButton & !INPORT_xGrinderBlocked & !INPORT_xNoCoffeeBeans) // Detect restart after interrupt
	{
		xInterrupted = false;
		OUTPORT_xGrinder = true;

		gettimeofday(&stInteruptStop, (struct timezone *)0);
		fInterruptStop = float64(stInteruptStop.tv_sec + stInteruptStop.tv_usec * 1e-6);

		fInterrupt = fInterruptStop - fInterruptStart + fInterrupt;
	}

	// *********************************************************************************************************
	// If the grinder is working, compare if the required grinding time is reached and stop grinder.
	// When grinder stops detect completion of the grinding process.
	// *********************************************************************************************************

	else if (OUTPORT_xGrinder)
	{
		OUTPORT_fActualGrindingDuration = fNow - fLastStart -fInterrupt;

		if ( OUTPORT_fActualGrindingDuration < OUTPORT_fNeededGrindingDuration ) // Required grinding time not reached
		{
			OUTPORT_xGrinder = true;
		}
		else if ( OUTPORT_fActualGrindingDuration >= OUTPORT_fNeededGrindingDuration ) // Required grinding time reached
		{
			OUTPORT_xGrinder = false;
		}

		if ( xFlagGrinder & ! OUTPORT_xGrinder) // Determine falling edge for grinder / grinder stops
		{
			OUTPORT_xGrinderFinish = true;
		}
	}

	// *********************************************************************************************************
	// If the reset is active, also reset the variables that informs about the completion of the grinding
	// process and reset the output times
	// *********************************************************************************************************

	else if (INPORT_xReset)
	{
		OUTPORT_xGrinderFinish = false;
		OUTPORT_fNeededGrindingDuration = 0.0;
		OUTPORT_fActualGrindingDuration = 0.0;
		fInterrupt = 0.0;
	}

	// *********************************************************************************************************
	// Set flags for edge detection
	// *********************************************************************************************************

	xFlagStartButton = INPORT_xStartButton;
	xFlagGrinder = OUTPORT_xGrinder;
	xFlagInterrupt = INPORT_xStopButton;
}

} // end of namespace LIB_Grinder
