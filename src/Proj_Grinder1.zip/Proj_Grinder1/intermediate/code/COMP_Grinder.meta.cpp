﻿#include "COMP_Grinder.hpp"

namespace LIB_Grinder
{

void COMP_Grinder::RegisterComponentPorts()
{
}

} // end of namespace LIB_Grinder