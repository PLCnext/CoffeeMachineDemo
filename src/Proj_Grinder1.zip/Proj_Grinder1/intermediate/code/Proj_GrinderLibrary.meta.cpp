﻿#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeSystem.h"
#include "PG_Grinder.hpp"
#include "Proj_GrinderLibrary.hpp"

namespace LIB_Grinder
{

using namespace Arp::Plc::Commons::Meta;

    void Proj_GrinderLibrary::InitializeTypeDomain()
    {
        this->typeDomain.AddTypeDefinitions
        (
            // Begin TypeDefinitions
            {
                {   // ProgramDefinition: LIB_Grinder::PG_Grinder
                    DataType::Program, CTN<LIB_Grinder::PG_Grinder>(), sizeof(::LIB_Grinder::PG_Grinder), alignof(::LIB_Grinder::PG_Grinder), StandardAttribute::None,
                    {
                        // FieldDefinitions:
                        { "INPORT_uiIntensity", offsetof(::LIB_Grinder::PG_Grinder, INPORT_uiIntensity), DataType::UInt16, String::Empty, sizeof(uint16), alignof(uint16), {  }, StandardAttribute::Input },
                        { "INPORT_xStartButton", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xStartButton), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "INPORT_xStopButton", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xStopButton), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "INPORT_xReset", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xReset), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "INPORT_xGrinderBlocked", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xGrinderBlocked), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "INPORT_xNoCoffeeBeans", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xNoCoffeeBeans), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "INPORT_xPot", offsetof(::LIB_Grinder::PG_Grinder, INPORT_xPot), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Input },
                        { "OUTPORT_xGrinder", offsetof(::LIB_Grinder::PG_Grinder, OUTPORT_xGrinder), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Output },
                        { "OUTPORT_xGrinderFinish", offsetof(::LIB_Grinder::PG_Grinder, OUTPORT_xGrinderFinish), DataType::Boolean, String::Empty, sizeof(boolean), alignof(boolean), {  }, StandardAttribute::Output },
                        { "OUTPORT_fNeededGrindingDuration", offsetof(::LIB_Grinder::PG_Grinder, OUTPORT_fNeededGrindingDuration), DataType::Float64, String::Empty, sizeof(float64), alignof(float64), {  }, StandardAttribute::Output },
                        { "OUTPORT_fActualGrindingDuration", offsetof(::LIB_Grinder::PG_Grinder, OUTPORT_fActualGrindingDuration), DataType::Float64, String::Empty, sizeof(float64), alignof(float64), {  }, StandardAttribute::Output },
                    }
                },
            }
            // End TypeDefinitions
        );
    }

} // end of namespace LIB_Grinder

