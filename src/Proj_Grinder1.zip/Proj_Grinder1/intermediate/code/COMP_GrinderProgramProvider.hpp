﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Esm/ProgramProviderBase.hpp"

namespace LIB_Grinder
{

using namespace Arp;
using namespace Arp::Plc::Commons::Esm;

//forwards
class COMP_Grinder;

class COMP_GrinderProgramProvider : public ProgramProviderBase
{

public:   // construction/destruction
    COMP_GrinderProgramProvider(COMP_Grinder& cOMP_GrinderArg);
    virtual ~COMP_GrinderProgramProvider() = default;

public:   // IProgramProvider operations
    IProgram::Ptr CreateProgramInternal(const String& programName, const String& programType) override;

private:   // deleted methods
    COMP_GrinderProgramProvider(const COMP_GrinderProgramProvider& arg) = delete;
    COMP_GrinderProgramProvider& operator=(const COMP_GrinderProgramProvider& arg) = delete;

private: // fields
    COMP_Grinder& cOMP_Grinder;
};

///////////////////////////////////////////////////////////////////////////////
// inline methods of class COMP_GrinderProgramProvider

inline COMP_GrinderProgramProvider::COMP_GrinderProgramProvider(COMP_Grinder& cOMP_GrinderArg)
    : cOMP_Grinder(cOMP_GrinderArg)
{
}

} // end of namespace LIB_Grinder
