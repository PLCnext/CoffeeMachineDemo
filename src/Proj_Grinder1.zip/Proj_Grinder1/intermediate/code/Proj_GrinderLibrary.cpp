﻿#include "Proj_GrinderLibrary.hpp"
#include "Arp/System/Core/CommonTypeName.hxx"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeSystem.h"
#include "COMP_Grinder.hpp"

namespace LIB_Grinder
{

Proj_GrinderLibrary::Proj_GrinderLibrary(AppDomain& appDomain)
    : MetaLibraryBase(appDomain, ARP_VERSION_CURRENT, typeDomain)
    , typeDomain(CommonTypeName<Proj_GrinderLibrary>().GetNamespace())
{
    this->componentFactory.AddFactoryMethod(CommonTypeName<::LIB_Grinder::COMP_Grinder>(), &::LIB_Grinder::COMP_Grinder::Create);
    this->InitializeTypeDomain();
}

void Proj_GrinderLibrary::Main(AppDomain& appDomain)
{
    SingletonBase::CreateInstance(appDomain);
}

extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain)
{
    Proj_GrinderLibrary::Main(appDomain);
    return  Proj_GrinderLibrary::GetInstance();
}

} // end of namespace LIB_Grinder
