﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/System/Core/AppDomain.hpp"
#include "Arp/System/Core/Singleton.hxx"
#include "Arp/System/Core/Library.h"
#include "Arp/Plc/Commons/Meta/MetaLibraryBase.hpp"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeDomain.hpp"

namespace LIB_Grinder
{

using namespace Arp::System::Acf;
using namespace Arp::Plc::Commons::Meta;
using namespace Arp::Plc::Commons::Meta::TypeSystem;

class Proj_GrinderLibrary : public MetaLibraryBase, public Singleton<Proj_GrinderLibrary>
{
public: // typedefs
    typedef Singleton<Proj_GrinderLibrary> SingletonBase;

public: // construction/destruction
    Proj_GrinderLibrary(AppDomain& appDomain);
    virtual ~Proj_GrinderLibrary() = default;

public: // static operations (called through reflection)
    static void Main(AppDomain& appDomain);

private: // methods
    void InitializeTypeDomain();

private: // deleted methods
    Proj_GrinderLibrary(const Proj_GrinderLibrary& arg) = delete;
    Proj_GrinderLibrary& operator= (const Proj_GrinderLibrary& arg) = delete;

private:  // fields
    TypeDomain typeDomain;
};

extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain);

///////////////////////////////////////////////////////////////////////////////
// inline methods of class Proj_GrinderLibrary

} // end of namespace LIB_Grinder
