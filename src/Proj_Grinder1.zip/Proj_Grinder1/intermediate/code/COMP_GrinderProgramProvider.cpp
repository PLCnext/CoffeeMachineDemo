﻿#include "COMP_GrinderProgramProvider.hpp"
#include "PG_Grinder.hpp"

namespace LIB_Grinder
{

IProgram::Ptr COMP_GrinderProgramProvider::CreateProgramInternal(const String& programName, const String& programType)
{
    if (programType == "PG_Grinder")
    { 
        return std::make_shared<::LIB_Grinder::PG_Grinder>(this->cOMP_Grinder, programName);
    }

    // else unknown program
    return nullptr;
}

} // end of namespace LIB_Grinder
