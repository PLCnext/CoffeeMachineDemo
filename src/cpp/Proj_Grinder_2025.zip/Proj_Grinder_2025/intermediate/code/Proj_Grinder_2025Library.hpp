#pragma once
#include "Arp/System/Core/Arp.h"
#if ARP_ABI_VERSION_MAJOR < 2
#include "Arp/System/Core/AppDomain.hpp"
#include "Arp/System/Core/Singleton.hxx"
#include "Arp/System/Core/Library.h"
#endif
#include "Arp/Plc/Commons/Meta/MetaLibraryBase.hpp"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeDomain.hpp"

namespace Grinder
{

#if ARP_ABI_VERSION_MAJOR < 2
using namespace Arp::System::Acf;
#else
using namespace Arp::Base::Acf::Commons;
#endif
using namespace Arp::Plc::Commons::Meta;
using namespace Arp::Plc::Commons::Meta::TypeSystem;

class Proj_Grinder_2025Library : public MetaLibraryBase
#if ARP_ABI_VERSION_MAJOR < 2
    , public Singleton<Proj_Grinder_2025Library>
#endif
{
#if ARP_ABI_VERSION_MAJOR < 2
public: // typedefs
    typedef Singleton<Proj_Grinder_2025Library> SingletonBase;
#else
    Proj_Grinder_2025Library(void);
#endif
public: // construction/destruction
#if ARP_ABI_VERSION_MAJOR < 2
    Proj_Grinder_2025Library(AppDomain& appDomain);
    virtual ~Proj_Grinder_2025Library() = default;

public: // static operations (called through reflection)
    static void Main(AppDomain& appDomain);
#else
    static Proj_Grinder_2025Library& GetInstance();
#endif

private: // methods
    void InitializeTypeDomain();

#if ARP_ABI_VERSION_MAJOR < 2
private: // deleted methods
    Proj_Grinder_2025Library(const Proj_Grinder_2025Library& arg) = delete;
    Proj_Grinder_2025Library& operator= (const Proj_Grinder_2025Library& arg) = delete;
#endif
private:  // fields
    TypeDomain typeDomain;
};

#if ARP_ABI_VERSION_MAJOR < 2
extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain);
#endif
///////////////////////////////////////////////////////////////////////////////
// inline methods of class Proj_Grinder_2025Library

} // end of namespace Grinder
