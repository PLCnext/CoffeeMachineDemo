#include "COMP_GrinderProgramProvider.hpp"
#include "PG_Grinder.hpp"

namespace Grinder
{

#if ARP_ABI_VERSION_MAJOR < 2
#else
COMP_GrinderProgramProvider::COMP_GrinderProgramProvider(COMP_Grinder& cOMP_GrinderArg)
    : cOMP_Grinder(cOMP_GrinderArg)
{
}

#endif
IProgram::Ptr COMP_GrinderProgramProvider::CreateProgramInternal(const String& programName, const String& programType)
{
    if (programType == "PG_Grinder")
    { 
        return std::make_shared<::Grinder::PG_Grinder>(this->cOMP_Grinder, programName);
    }

    // else unknown program
    return nullptr;
}

} // end of namespace Grinder
