#include "COMP_Grinder.hpp"

namespace Grinder
{

void COMP_Grinder::RegisterComponentPorts()
{
}

} // end of namespace Grinder