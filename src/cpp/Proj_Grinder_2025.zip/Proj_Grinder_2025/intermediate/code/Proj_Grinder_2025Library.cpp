#include "Proj_Grinder_2025Library.hpp"
#if ARP_ABI_VERSION_MAJOR < 2
#include "Arp/System/Core/CommonTypeName.hxx"
#else
#include "Arp/Base/Core/CommonTypeName.hxx"
#include "Proj_Grinder_2025LibraryInfo.hpp"
#endif
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeSystem.h"
#include "COMP_Grinder.hpp"

namespace Grinder
{
#if ARP_ABI_VERSION_MAJOR < 2
Proj_Grinder_2025Library::Proj_Grinder_2025Library(AppDomain& appDomain)
    : MetaLibraryBase(appDomain, ARP_VERSION_CURRENT, typeDomain)
    , typeDomain(CommonTypeName<Proj_Grinder_2025Library>().GetNamespace())
#else
Proj_Grinder_2025Library::Proj_Grinder_2025Library()
    : MetaLibraryBase(Proj_Grinder_2025LibraryVersion, typeDomain)
    , typeDomain(CommonTypeName<Proj_Grinder_2025Library>().GetNamespace())
#endif
{
#if ARP_ABI_VERSION_MAJOR < 2
    this->componentFactory.AddFactoryMethod(CommonTypeName<::Grinder::COMP_Grinder>(), &::Grinder::COMP_Grinder::Create);
#else
 
    this->AddComponentType<::Grinder::COMP_Grinder>();
#endif
    this->InitializeTypeDomain();
}

#if ARP_ABI_VERSION_MAJOR < 2
void Proj_Grinder_2025Library::Main(AppDomain& appDomain)
{
    SingletonBase::CreateInstance(appDomain);
}
#else
Proj_Grinder_2025Library& Proj_Grinder_2025Library::GetInstance()
{
    static Proj_Grinder_2025Library instance;
    return instance;
}
#endif

#if ARP_ABI_VERSION_MAJOR < 2
extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain)
{
    Proj_Grinder_2025Library::Main(appDomain);
    return  Proj_Grinder_2025Library::GetInstance();
}

} // end of namespace Grinder
#else
} // end of namespace Grinder
extern "C" ARP_EXPORT Arp::Base::Acf::Commons::ILibrary& Proj_Grinder_2025_MainEntry()
{
    return  Grinder::Proj_Grinder_2025Library::GetInstance();
}
#endif

