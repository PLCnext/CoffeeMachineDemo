#include "COMP_Grinder.hpp"
#include "Arp/Plc/Commons/Esm/ProgramComponentBase.hpp"
#include "Proj_Grinder_2025Library.hpp"

namespace Grinder
{
#if ARP_ABI_VERSION_MAJOR < 2
COMP_Grinder::COMP_Grinder(IApplication& application, const String& name)
: ComponentBase(application, ::Grinder::Proj_Grinder_2025Library::GetInstance(), name, ComponentCategory::Custom)
    , programProvider(*this)
    , ProgramComponentBase(::Grinder::Proj_Grinder_2025Library::GetInstance().GetNamespace(), programProvider)
#else
COMP_Grinder::COMP_Grinder(ILibrary& library, const String& name)
    : ComponentBase(library, name, ComponentCategory::Custom, GetDefaultStartOrder())
    , programProvider(*this)
    , ProgramComponentBase(::Grinder::Proj_Grinder_2025Library::GetInstance().GetNamespace(), programProvider)
#endif
{
}

void COMP_Grinder::Initialize()
{
    // never remove next line
    ProgramComponentBase::Initialize();

    // subscribe events from the event system (Nm) here
}

void COMP_Grinder::LoadConfig()
{
    // load project config here
}

void COMP_Grinder::SetupConfig()
{
    // never remove next line
    ProgramComponentBase::SetupConfig();

    // setup project config here
}

void COMP_Grinder::ResetConfig()
{
    // never remove next line
    ProgramComponentBase::ResetConfig();

    // implement this inverse to SetupConfig() and LoadConfig()
}

void COMP_Grinder::PowerDown()
{
	// implement this only if data shall be retained even on power down event
	// will work only for PLCnext controllers with an "Integrated uninterruptible power supply (UPS)"
	// Available with 2021.6 FW
}

} // end of namespace Grinder
