#include "Arp/Base/Core/Arp.hpp"

namespace Grinder
{

	const ArpVersion Proj_Grinder_2025LibraryVersion = ArpVersion(1); // adjust your library version number here

} // end of namespace Grinder
